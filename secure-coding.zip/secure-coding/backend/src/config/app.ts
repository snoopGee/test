export const {
    APP_PORT,
    NODE_ENV
} = process.env