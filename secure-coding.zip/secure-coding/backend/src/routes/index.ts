export { default as home } from './auth'

export { default as test } from './test'