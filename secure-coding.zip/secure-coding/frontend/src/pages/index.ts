export { default as Home } from './Home'

export { default as Admin } from './Admin'

export { default as Profile } from './Profile'

export { default as Transfer } from './Transfer'

export { default as Register } from './Register'

export { default as EditProfile } from './EditProfile'