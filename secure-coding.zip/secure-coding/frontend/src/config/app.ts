export const { REACT_APP_API_ENDPOINT } = process.env;
